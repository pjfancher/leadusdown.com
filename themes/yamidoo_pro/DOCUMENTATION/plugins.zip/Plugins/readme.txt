Recommended plug-ins are not required to install, but they will give more functions to your website.

wp-pagenavi.2.61.zip - is for pagination on homepage
easy-contact.0.1.2.zip - is to create a page with Contact Form
subscribe-to-comments.zip - will allow to commenters to subscribe to future comments on an article.